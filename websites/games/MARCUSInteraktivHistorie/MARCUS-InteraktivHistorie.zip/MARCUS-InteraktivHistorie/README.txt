LINK TO STORY:
https://og-design.github.io/websites/games/gameLink/index.html

Play in iframe or by clicking the title.

