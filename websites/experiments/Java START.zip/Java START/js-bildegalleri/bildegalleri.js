let bilde = document.getElementById("bilde");



// bilde.src = "bilder/ravine.jpg";




let bildeGalleri = [
    // begynner på 0
    "ravine.jpg", 
    "ravine2.jpg",
    "ravineDivers.jpg",
    "ravine3.jpg",
    "ravine4.webp"
];



// bilde.src = "bilder/" + bildeGalleri[0];

let aktivtBilde = 0;

bilde.src = "bilder/" + bildeGalleri[aktivtBilde]

setInterval(skiftBilde, 5000)

function skiftBilde() {
    aktivtBilde = aktivtBilde + 1;
    if (aktivtBilde > bildeGalleri.length -1) { //sjekker om jeg er utenfor array legnth
        aktivtBilde = 0;
    } else {//no need for else here
        
    }

    bilde.src = "bilder/" + bildeGalleri[aktivtBilde];
}