// when button click
// recieve user input
// if number right write: you guessed the correct number
// else if number to high write: to high
// else write: to low

let correctNumber = 8;

let guess = prompt("Guess a number between 0 and 10: ");

// == compares to values
if (guess == correctNumber) {
    console.log("you guessed the correct number: ", guess);
}
else if (guess < correctNumber) {
    console.log("you guessed a number that was to low: ", guess);
}
else if (guess > correctNumber) {
    console.log("you guessed a number that was too high: ", guess);
}


let correctNum2 = 3;
let guess2 = prompt("guess a number between 0 and 10");

console.log(guess2 > correctNum2);
console.log(guess2 < correctNum2);

if (guess2 == correctNum2){
    console.log("Correct! ");
}
else{
    console.log("Wrong! ");
}

