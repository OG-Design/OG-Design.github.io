// lett blir bare brukt når man lager nye variabler
let antallA = 7;

// predefined variable
antallB = 1;


// let tillater ikke flere variabler med samme navn
let antall = 2;
antall = 3;

// var tillater flere variabler med samme navn, 
// men de variablene senere i koden vil da overskrive de som var før.
// var antall = 2;
// var antall = 3;
// svar
// console.log(antall)


// for å vise svaret må vi enten skrive det ut i konsollen eller på nettsiden.

console.log(antallB);


// favorittTall
const favorittTall = 8;
console.log(favorittTall);


// let antall1 = 7; console.log(antall1);


// let verdi = null;
// console.log("verdi: "+ verdi)

// number datatype
// desimal tall
let andel = 0.56;

// hel tall
let heltall = 23;

let sitat = "noe tekst som ikke er langt, men heller ikke så kort"
console.log(sitat);
console.log(" sitat eksempler ");
console.log(sitat.length) //finner ut av lengden til sitat
console.log(sitat.indexOf("h")); // finner ut av tallverdien av - 
// - sitatets første e. 
// om den ikke finner indexOf bokstaven vil den vise:   -1 

console.log(sitat.indexOf("noe")); // finner ut av om sitat -
// - inneholder ordet "noe".

console.log(sitat[14]); // finner ut hva indexet 5 inneholder.
console.log(sitat.substring(15, 18)) //finner ut av hva som er mellom 15 og 18

let sum = 4 + 5;

console.log("space\nline 2\n\n") // \n creates a new line


// VareHoldning
let vareMengde = 90; // total mengde varer.

let varePrisEksMoms = 50; // pris pr vare eks. MVA..

let vareMoms = 0.25; // moms mengde i desimal.

let vareSolgt = 39; // total mengde solgte varer.


// Kalkuleringer ved bruk av operatorer.
vareGjennstående = vareMengde - vareSolgt;

vareInntektSumEksMoms = vareSolgt * varePrisEksMoms;

vareInntektSumMoms = vareInntektSumEksMoms * vareMoms;

vareInntektSumInklMoms = vareInntektSumEksMoms + vareInntektSumMoms;


// printing av resultat i konsollen.
console.log("Gjennstående vare mengde: ", vareGjennstående);

console.log("Vare inntekt  eks. moms: kr ,- ", vareInntektSumEksMoms);

console.log("Vare inntekt moms: kr ,- ", vareInntektSumMoms);

console.log("Total kostnader hos kunder: kr ,-", vareInntektSumInklMoms);


console.log("/n/n/n") // Spacing i konsollen

// modulus eller % gir oss resten av en divisjon
let rest1 = 9 % 3;
let rest2 = 8 % 3;

console.log(rest1," ", rest2)

let poeng = 0;
poeng += 3;

let text = "hei" + " på deg!";
console.log(text);

let tekst1 = "hei"; 
tekst1 += " på";
tekst1 += " deg!";

console.log(tekst1);

let tall1 = 19;
let tekst2 = "43";
let sum1 = tall1 + tekst2;

let noeTekst = "384";

console.log(typeof(noeTekst));

let tallFraTekst = Number(noeTekst);

console.log(typeof(tallFraTekst));

let tekst34 = "SomMerFerie";
tekst34 = tekst34.toUpperCase();
tekst34.substring(3, 6);
console.log(tekst34);

console.log(9 - 3 / (1/3) + 1)