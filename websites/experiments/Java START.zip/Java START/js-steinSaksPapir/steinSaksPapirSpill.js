
let stein = document.getElementById("steinElement");
let saks = document.getElementById("saksElement");
let papir = document.getElementById("papirElement");

stein.addEventListener("click", velgStein);

saks.addEventListener("click", velgSaks);

papir.addEventListener("click", velgPapir);


// programmert valg av stein, saks, eller papir, 
// avrundet med floor for å runde ned til et helt tall.
let programValgSteinSaksPapir = Math.floor(Math.random() * 3 ); 

let programValgStein = 0;
let programValgSaks = 1;
let programValgPapir = 2;

// skriver ut valget i konsoll slik at det blir lettere å feilsøke.
// if ( programValgSteinSaksPapir === 0 ) {
//     console.log("computerChoseStein");
// } else if ( programValgSteinSaksPapir === 1 ) {
//     console.log("computerChoseSaks");
// } else if ( programValgSteinSaksPapir ===2) {
//     console.log("computerChosePapir");
// }


// function for when result is a draw
function draw() {
    document.getElementById("output").innerHTML = "It was a draw!";
}

// function for when result is a loss
function lost() {
    document.getElementById("output").innerHTML = "You lost!";
}

// function for when result is won
function won() {
    document.getElementById("output").innerHTML = " You won!";
}

function valgteStein() {
    document.getElementById("output").innerHTML = "Bot chose stone, ";
}

// når velgStein er aktivert
function velgStein() {
    // sjekk for click bekreftelse
    console.log("steinClicked");

    // hvis valg = programValgSteinSaksPapir
    if ( programValgSteinSaksPapir === programValgStein ) {
        
        console.log("programmet valgte stein, det ble uavgjort! ");

        valgteStein(), draw();
        
        
    
    } else if ( programValgSteinSaksPapir === programValgSaks ) {
    
        console.log("programmet valgte saks, du vant! ");

        won();
    
    } else if ( programValgSteinSaksPapir === programValgPapir ) {
    
        console.log("programmet valgte papir, du tapte! ");
    
        lost();
    }
}

// når velgStein er aktivert
function velgSaks() {
    // sjekk for click bekreftelse
    console.log("saksClicked");

    // hvis valg = programValgSteinSaksPapir
    if ( programValgSteinSaksPapir === programValgStein ) {

        console.log("programmet valgte stein, du tapte! ");

        lost();
        
    } else if ( programValgSteinSaksPapir === programValgSaks ) {

        console.log("programmet valgte saks, det ble uavgjort! ")

        draw();

    } else if ( programValgSteinSaksPapir === programValgPapir ) {

        console.log("programmet valgte papir, du vant! ");

        won();

    }
}

// når velgPapir er aktivert
function velgPapir() {
    // sjekk for click bekreftelse
    console.log("papirClicked");

    // hvis valg = programValgSteinSaksPapir
    if ( programValgSteinSaksPapir === programValgStein ) {

        console.log("programmet valgte stein, du vant! ");

        won();

    } else if ( programValgSteinSaksPapir === programValgSaks ) {

        console.log("programmet valgte saks, du tapte! ");

        lost();

    } else if ( programValgSteinSaksPapir === programValgPapir) {

        console.log("programmet valgte papir, det ble uavgjort");

        draw();

    }
}



