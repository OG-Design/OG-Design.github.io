let height = prompt("how tall are you? cm");

// if height 100 or over ok but if height over 180 not ok
if (height >= 100 && height <= 180) {
    console.log("welcome");
}
else {
    console.log("get out");
}

