
// definition of tempFarenheit
// let tempFarenheit = 90;

// definition of tempCelcius
// let tempCelcius = (tempFarenheit - 32) * (5/9);

let farenheit= 100;
let tempCelcius = Math.round((farenheit-32)/1.8);

let tempCelciusId = document.getElementById("tempCelcius", farenheit);
tempCelciusId.addEventListener();


// if () {

// } else {

// }

// Writes result to the website
// console.log(tempFarenheit + " farenheit is equals to " + tempCelcius + " Celcius. ");
console.log(tempCelcius);
