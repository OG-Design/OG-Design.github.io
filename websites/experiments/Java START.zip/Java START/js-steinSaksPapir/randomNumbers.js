//skriver ut et tilfeldig tall mellom 0 og 1
let random = Math.random();
console.log(random);

//skriver ut et tilfeldig tall mellom 1 og 4, output blir mellom 0 og 3.
let random1to4 = Math.random() * 4;
console.log(Math.floor(random1to4));

//skriver ut et tilfeldig tall mellom 5 og 11
let random5to11 = Math.random() * 6 + 5;
console.log(Math.floor(random5to11));

//enkel stein saks papir fra programmet
let tilfeldigValg = Math.floor(Math.random() * 3);

if (tilfeldigValg === 0) {
    console.log("stein");
}
else if (tilfeldigValg === 1) {
    console.log("saks");
}
else if (tilfeldigValg === 2) {
    console.log("papir");
}

