console.log(5 == "5"); //Skriver ut true fordi det er samme innhold.
console.log(5 === "5"); //Skriver ut false,
// fordi det er av forskjellige datatyper.

console.log("/n/n/n");

console.log(5 != 4);
console.log(5 != 5);
console.log(5 != "5");
console.log(5 !== 4);
console.log(5 !== "5");


let a = 3;
let b = 7;
let c = "7";

console.log(b == c);
console.log(b === c);
console.log(a < b);
console.log(a <= b);
console.log(a > b);
console.log(a != b);
console.log(b != c);
console.log(b !== c);


