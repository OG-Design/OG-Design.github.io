// () means function
/* 
    multiline
    comment
    yay
*/

// prompts a box in a browser.
// alert(
// "Loading into page"
// );

// console.log("Dette er en utskrift i konsollen")


// /*
// spør etter navnet til besøkende, og skriver ut.
// lagrer bruker_navn

// "" = String

// bruker_navn inhold som bruker svarer, kategorisering

// prompt spør om input.


// console.log(bruker_navn)
// refererer til bruker_navn å skriver det ut i konsollen.

// */

// // variabel er bruker_navn
// let bruker_navn = prompt("hei hva heter du? ");
// console.log(bruker_navn);

// // gets information from parent, in this case index.html
// document.getElementById("titlePrint").innerText = "Hei, " + bruker_navn + "!";




// // finds age based on 2024 - birthYear
// let birthYear = prompt("What year where you born?");


// // gets current date/time
// let time = new Date(); // getFullYear

// let age = time.getFullYear() - birthYear;

// // console check time
// console.log(time.getFullYear());

// // console check
// console.log(age);


// document.getElementById("age").innerText = "you are " + age + " years old."; 


// let farge = prompt("favorittfarge, små bokstaver på engelsk");
// // document.body.style.backgroundColor = farge;


// document.querySelector("body").style.backgroundColor = farge;


let gradient = prompt("gradient farge: farge1, farge2");

document.querySelector("body").style.background = "linear-gradient(" + gradient + ")";




// imageGallery


let imgOneJs = "one";
let imgTwoJs = "two";
let imgThreeJs = "three";

const imageArray = ["one", "two", "three"];

