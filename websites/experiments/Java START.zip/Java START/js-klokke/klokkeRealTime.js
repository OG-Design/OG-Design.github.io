// Tid info full
let tid = Date();

document.getElementById("utskrift").innerText = tid;




/*
let tidStil = new Date();
new Date() - Does as suggested
tidStil - variable for getting a new Date
*/

let timeSelect = new Date();

setInterval(repeatTimePerSec, 1000);

function repeatTimePerSec() {
    let timeSelect = new Date();
    document.getElementById("timePrint").innerHTML = timeSelect.toLocaleTimeString();
}


/*
dateOutput = tidStil.getHours();
dateOutput - variable for getting date from tidstil.
*/
// let dateOutputHours = timeSelect.getHours();
// let dateOutputMinutes = timeSelect.getMinutes();
// let dateOutputSeconds = timeSelect.getSeconds();

// prints time to console
// console.log( timeSelect.getHours() + "h" + " : " + timeSelect.getMinutes() + "m" + " : " + timeSelect.getSeconds() + "s");


// document.getElementById("hoursPrint").innerText = dateOutputHours;
// document.getElementById("minutesPrint").innerText = dateOutputMinutes;
// document.getElementById("secondsPrint").innerText = dateOutputSeconds;

// // get full year...